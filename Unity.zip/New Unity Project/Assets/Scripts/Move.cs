﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Move : MonoBehaviour {
	
	public float horizontalSpeed;
	float speedX;
	float speedZ;
	float speedY;
	public float verticalImpulse;
	Rigidbody2D rb;
	bool isGrounded;
	CharacterController controller;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D> ();
		controller = GetComponent<CharacterController> ();
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (Input.GetKey(KeyCode.A)) {
			speedX = -horizontalSpeed;
		}
		else if (Input.GetKey(KeyCode.D)) {
			speedX = horizontalSpeed;
		}
		if (Input.GetKey(KeyCode.S)) {
			speedZ = -horizontalSpeed;
		}
		else if (Input.GetKey(KeyCode.W)) {
			speedZ = horizontalSpeed;
		}
		if (Input.GetKeyDown(KeyCode.Space)) {
			//rb.AddForce(new Vector2(0, verticalImpulse), ForceMode.Impulse);
			speedY = horizontalSpeed;
		}
		transform.Translate(speedX, 0, 0);
		speedX = 0;
		transform.Translate(0, 0, speedZ);
		speedZ = 0;
		transform.Translate(0, speedY, 0);
		speedY = 0;
	}
}